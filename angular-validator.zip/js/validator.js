function angularValidator(e) {
  if (e.keyCode == 13) {
    let letters = /^[A-Za-z]+$/;
    let inputtxt = document.getElementById("input-value").value;
    if (letters.test(inputtxt)) {
      document.getElementById("target-result").innerHTML += "";
      document.getElementById("target-result").innerHTML += "Invalid";
    } else {
      document.getElementById("target-result").innerHTML += "";
      document.getElementById("target-result").innerHTML += "Valid";
    }

    return false;
  }
}
