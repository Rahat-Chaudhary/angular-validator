function angularValidator(e) {
  if (e.keyCode == 13) {
    let letters = /^[A-Za-z]+$/;
    let inputtxt = document.getElementById("input-value");
    if (inputtxt.value.match(letters)) {
      document.getElementById("target-result").innerHTML += "";
      document.getElementById("target-result").innerHTML += "Invalid";
      return true;
    }
    document.getElementById("target-result").innerHTML += "";
    document.getElementById("target-result").innerHTML += "Valid";
    return false;
  }
}
